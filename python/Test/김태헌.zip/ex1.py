r = int(input("반지름 입력: "))
print("원의 넓이" + str(r * r * 3.14))