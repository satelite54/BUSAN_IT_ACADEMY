top = 23
bottom = 34
height = 13
print((top + bottom) * height / 2)