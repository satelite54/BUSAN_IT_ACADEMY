a = 173000
b = a * 0.03
print(a + b)