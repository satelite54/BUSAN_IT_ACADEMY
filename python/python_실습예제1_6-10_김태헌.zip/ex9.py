a = int(input("1과목 : "))
b = int(input("2과목 : "))
c = int(input("3과목 : "))
d = int(input("4과목 : "))
e = int(input("5과목 : "))

sum = a + b + c + d + e

print(sum)
print(sum/5)