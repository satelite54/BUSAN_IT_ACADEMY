strInput = str(input("영어 문장 입력 :"))
print("단어를 모두 대문자로 표시: " + strInput.upper())
print("입력된 단어의 길이: " + str(len(strInput)))
print("단어에 t가 몇번 나오는가?: " + str(strInput.count('t')))