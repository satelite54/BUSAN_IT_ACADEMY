a = 56000
b = a * 0.1
print(a + b)