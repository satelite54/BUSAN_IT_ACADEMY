def recArea(w, h):
    return w * h

w = int(input("밑변 입력 :"))
h = int(input("높이 입력 :"))
print("사각형의 넓이 : " + str(recArea(w, h)))
