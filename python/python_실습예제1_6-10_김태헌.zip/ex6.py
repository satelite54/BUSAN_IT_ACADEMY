a = 23
print(3.14 * a * a)