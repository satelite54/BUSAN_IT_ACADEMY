import math

r = 10
h = 100
print("원기둥의 부피는", math.pi*r*r*h)